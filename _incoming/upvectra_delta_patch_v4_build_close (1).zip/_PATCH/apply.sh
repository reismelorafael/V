#!/bin/sh
set -eu
ROOT="${1:-.}"

copy_one() {
  src="$1"
  dst="$2"
  mkdir -p "$(dirname "$dst")"
  cp -f "$src" "$dst"
}

# overlay patch files into repo
copy_one "$(dirname "$0")/../app/src/main/res/layout/importexport.xml" "$ROOT/app/src/main/res/layout/importexport.xml"
copy_one "$(dirname "$0")/../app/src/main/java/com/vectras/vm/core/ProcessRuntimeOps.java" "$ROOT/app/src/main/java/com/vectras/vm/core/ProcessRuntimeOps.java"
copy_one "$(dirname "$0")/../app/src/main/java/com/vectras/vm/core/ProcessSupervisor.java" "$ROOT/app/src/main/java/com/vectras/vm/core/ProcessSupervisor.java"

echo "OK: applied v4 (build+close) patch"
