# upvectra_delta_patch_v4 (build + close)
This patch contains ONLY 3 modified files + apply script.

## Fix build
- app/src/main/res/layout/importexport.xml
  - Move XML declaration to first line (no comment before it)
  - Remove stray attribute lines outside of tags
  - Keep same ids used by code.

## Fix "não fecha" / zombie tail
- app/src/main/java/com/vectras/vm/core/ProcessRuntimeOps.java
  - add ProcessRuntimeOps.forceKillTree(Process)
  - killTree(pid, SIGTERM/SIGKILL) bounded BFS scanning /proc for PPid

- app/src/main/java/com/vectras/vm/core/ProcessSupervisor.java
  - on kill_timeout, call ProcessRuntimeOps.forceKillTree() then await briefly again
