package com.vectras.vm.core;

import android.os.SystemClock;
import android.system.Os;
import android.system.OsConstants;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

/**
 * Operações runtime de processo centralizadas para reduzir redundância,
 * manter compatibilidade entre toolchains e preservar comportamento determinístico.
 */
public final class ProcessRuntimeOps {

    private static final long DESTROY_GRACE_PERIOD_MS = 250L;

    public enum ExecutionCategory {
        INTERACTIVE(3_000L, TimeUnit.MILLISECONDS),
        NON_INTERACTIVE(1_500L, TimeUnit.MILLISECONDS),
        SETUP_EXTRACTION(120L, TimeUnit.SECONDS),
        QUICK_QUERY(700L, TimeUnit.MILLISECONDS);

        private final long timeout;
        private final TimeUnit timeUnit;

        ExecutionCategory(long timeout, TimeUnit timeUnit) {
            this.timeout = timeout;
            this.timeUnit = timeUnit;
        }

        public long timeout() {
            return timeout;
        }

        public TimeUnit timeUnit() {
            return timeUnit;
        }
    }

    public static final class TimeoutExecutionResult {
        public enum Status {
            SUCCESS,
            ERROR,
            TIMEOUT
        }

        public final Status status;
        public final int exitCode;
        public final boolean timedOut;
        public final String message;

        private TimeoutExecutionResult(Status status, int exitCode, boolean timedOut, String message) {
            this.status = status;
            this.exitCode = exitCode;
            this.timedOut = timedOut;
            this.message = message;
        }

        public static TimeoutExecutionResult success(int exitCode, String message) {
            return new TimeoutExecutionResult(Status.SUCCESS, exitCode, false, message);
        }

        public static TimeoutExecutionResult timeout(int exitCode, String message) {
            return new TimeoutExecutionResult(Status.TIMEOUT, exitCode, true, message);
        }

        public static TimeoutExecutionResult failed(String message) {
            return new TimeoutExecutionResult(Status.ERROR, -1, false, message);
        }
    }

    private ProcessRuntimeOps() {
        throw new AssertionError("ProcessRuntimeOps is utility-only");
    }

    public static long monoMs() {
        return SystemClock.elapsedRealtime();
    }

    public static long wallMs() {
        return System.currentTimeMillis();
    }

    public static long safePid(Process process) {
        if (process == null) return -1L;
        try {
            Method method = Process.class.getMethod("pid");
            Object value = method.invoke(process);
            if (value instanceof Long) {
                long pid = (Long) value;
                if (pid > 0L) {
                    return pid;
                }
            }
        } catch (Exception ignored) {
        }

        try {
            Field field = process.getClass().getDeclaredField("pid");
            field.setAccessible(true);
            try {
                long reflectedPid = field.getLong(process);
                if (reflectedPid > 0L) {
                    return reflectedPid;
                }
            } finally {
                field.setAccessible(false);
            }
        } catch (Exception ignored) {
        }

        return -1L;
    }

    public static boolean isQmpAck(String result) {
        return result != null && result.contains("return");
    }

    public static boolean isLikelyInteractiveCommand(String command) {
        String normalized = command == null ? "" : command.trim().toLowerCase();
        return normalized.isEmpty()
                || "bash".equals(normalized)
                || "sh".equals(normalized)
                || normalized.startsWith("top")
                || normalized.startsWith("vi")
                || normalized.startsWith("vim")
                || normalized.startsWith("less")
                || normalized.startsWith("more");
    }

    public static TimeoutExecutionResult waitForWithCategory(Process process, ExecutionCategory category) {
        return waitForByCategory(process, category);
    }

    public static TimeoutExecutionResult waitForByCategory(Process process, ExecutionCategory category) {
        if (process == null) {
            return TimeoutExecutionResult.failed("process_missing");
        }
        if (category == null) {
            return TimeoutExecutionResult.failed("category_missing");
        }
        return waitForWithTimeout(process, category.timeout(), category.timeUnit(), category.name().toLowerCase());
    }

    public static TimeoutExecutionResult waitForWithTimeout(Process process,
                                                            long timeout,
                                                            TimeUnit timeUnit,
                                                            String label) {
        if (process == null) {
            return TimeoutExecutionResult.failed("process_missing");
        }
        if (timeUnit == null) {
            return TimeoutExecutionResult.failed("time_unit_missing");
        }
        try {
            if (!process.waitFor(Math.max(0L, timeout), timeUnit)) {
                return terminateAfterTimeout(process, label);
            }
            return TimeoutExecutionResult.success(process.exitValue(), label + "_exit");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return TimeoutExecutionResult.failed(label + "_interrupted");
        } catch (IllegalThreadStateException e) {
            return TimeoutExecutionResult.failed(label + "_not_terminated");
        }
    }

    public static boolean stopProcessWithTimeout(Process process,
                                                 long gracefulTimeoutMs,
                                                 long forcedTimeoutMs) {
        if (process == null || !process.isAlive()) {
            return true;
        }
        process.destroy();
        if (waitForExit(process, Math.max(1L, gracefulTimeoutMs), TimeUnit.MILLISECONDS) != Integer.MIN_VALUE) {
            return true;
        }
        process.destroyForcibly();
        return waitForExit(process, Math.max(1L, forcedTimeoutMs), TimeUnit.MILLISECONDS) != Integer.MIN_VALUE;
    }

    private static TimeoutExecutionResult terminateAfterTimeout(Process process, String label) {
        process.destroy();
        int exitCodeAfterDestroy = waitForExit(process, DESTROY_GRACE_PERIOD_MS, TimeUnit.MILLISECONDS);
        if (exitCodeAfterDestroy != Integer.MIN_VALUE) {
            return TimeoutExecutionResult.timeout(exitCodeAfterDestroy, label + "_timeout_destroy");
        }

        process.destroyForcibly();
        int exitCodeAfterForce = waitForExit(process, DESTROY_GRACE_PERIOD_MS, TimeUnit.MILLISECONDS);
        if (exitCodeAfterForce != Integer.MIN_VALUE) {
            return TimeoutExecutionResult.timeout(exitCodeAfterForce, label + "_timeout_forced");
        }

        return TimeoutExecutionResult.timeout(-1, label + "_timeout_kill_pending");
    }

    /**
     * Best-effort kill of a process tree (root + children) without shelling out.
     * This is intentionally conservative (bounded scan) to avoid UI stalls.
     *
     * @return true if a kill signal was attempted for at least one pid.
     */
    public static boolean forceKillTree(Process process) {
        if (process == null) return false;
        long pid = safePid(process);
        if (pid <= 0L) {
            // Fallback: still try Java destroyForcibly.
            try { process.destroyForcibly(); } catch (Throwable ignored) {}
            return false;
        }
        boolean attempted = killTree(pid, OsConstants.SIGTERM, 2, 96);
        attempted |= killTree(pid, OsConstants.SIGKILL, 3, 256);
        return attempted;
    }

    public static boolean killTree(long rootPid, int signal, int maxDepth, int maxPids) {
        if (rootPid <= 0L) return false;
        maxDepth = Math.max(1, Math.min(maxDepth, 6));
        maxPids = Math.max(16, Math.min(maxPids, 1024));

        Set<Long> visited = new HashSet<>();
        ArrayDeque<long[]> queue = new ArrayDeque<>();
        queue.add(new long[]{rootPid, 0});
        visited.add(rootPid);

        List<Long> ordered = new ArrayList<>();
        while (!queue.isEmpty() && visited.size() < maxPids) {
            long[] item = queue.removeFirst();
            long pid = item[0];
            int depth = (int) item[1];
            ordered.add(pid);

            if (depth >= maxDepth) continue;

            for (long child : listChildren(pid, maxPids)) {
                if (child <= 0L) continue;
                if (visited.add(child)) {
                    queue.add(new long[]{child, depth + 1});
                }
            }
        }

        // Kill children first (reverse), then root.
        boolean attempted = false;
        for (int i = ordered.size() - 1; i >= 0; i--) {
            attempted |= killPid(ordered.get(i), signal);
        }
        return attempted;
    }

    private static boolean killPid(long pid, int signal) {
        if (pid <= 0L) return false;
        try {
            Os.kill((int) pid, signal);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static List<Long> listChildren(long parentPid, int maxPids) {
        List<Long> children = new ArrayList<>();
        File proc = new File("/proc");
        File[] entries = proc.listFiles();
        if (entries == null) return children;

        for (File entry : entries) {
            if (children.size() >= Math.max(8, maxPids)) break;
            String name = entry.getName();
            if (name == null) continue;
            int len = name.length();
            if (len == 0 || len > 10) continue;
            for (int i = 0; i < len; i++) {
                char c = name.charAt(i);
                if (c < '0' || c > '9') { name = null; break; }
            }
            if (name == null) continue;

            long pid;
            try { pid = Long.parseLong(entry.getName()); }
            catch (NumberFormatException e) { continue; }

            long ppid = readPpidFromStatus(new File(entry, "status"));
            if (ppid == parentPid) {
                children.add(pid);
            }
        }
        return children;
    }

    private static long readPpidFromStatus(File statusFile) {
        if (statusFile == null || !statusFile.exists()) return -1L;
        try (BufferedReader br = new BufferedReader(new FileReader(statusFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("PPid:")) {
                    String v = line.substring(5).trim();
                    try { return Long.parseLong(v); } catch (NumberFormatException ignored) { return -1L; }
                }
            }
        } catch (Throwable ignored) {
        }
        return -1L;
    }


    private static int waitForExit(Process process, long timeout, TimeUnit unit) {
        try {
            if (!process.waitFor(Math.max(0L, timeout), unit)) {
                return Integer.MIN_VALUE;
            }
            return process.exitValue();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return Integer.MIN_VALUE;
        } catch (IllegalThreadStateException e) {
            return Integer.MIN_VALUE;
        }
    }
}
