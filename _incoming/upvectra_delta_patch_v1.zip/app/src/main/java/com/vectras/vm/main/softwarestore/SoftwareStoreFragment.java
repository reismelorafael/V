package com.vectras.vm.main.softwarestore;

import android.os.Bundle;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.transition.MaterialFadeThrough;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.vectras.vm.AppConfig;
import com.vectras.vm.main.romstore.DataRoms;
import com.vectras.vm.databinding.FragmentHomeSoftwareStoreBinding;
import com.vectras.vm.main.core.SharedData;
import com.vectras.vm.main.MainUiStateViewModel;
import com.vectras.vm.network.RequestNetwork;
import com.vectras.vm.network.RequestNetworkController;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class SoftwareStoreFragment extends Fragment {

    FragmentHomeSoftwareStoreBinding binding;
    private RequestNetwork net;
    private RequestNetwork.RequestListener _net_request_listener;
    private String contentJSON = "[]";
    SoftwareStoreViewModel homeSoftwareStoreViewModel;
    MainUiStateViewModel mainUiStateViewModel;
    SoftwareStoreHomeAdapter mAdapter;
    List<DataRoms> data = new ArrayList<>();

    private SoftwareStoreCallToHomeListener softwareStoreCallToHomeListener;
    public interface SoftwareStoreCallToHomeListener {
        void updateSearchStatus(boolean isReady);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setEnterTransition(new MaterialFadeThrough());
        setReturnTransition(new MaterialFadeThrough());
        setExitTransition(new MaterialFadeThrough());
        setReenterTransition(new MaterialFadeThrough());
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof SoftwareStoreCallToHomeListener) {
            softwareStoreCallToHomeListener = (SoftwareStoreCallToHomeListener) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        softwareStoreCallToHomeListener = null;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentHomeSoftwareStoreBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mAdapter = new SoftwareStoreHomeAdapter(getContext(), data);
        binding.rvSoftwarelist.setAdapter(mAdapter);
        binding.rvSoftwarelist.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));

        homeSoftwareStoreViewModel = new ViewModelProvider(requireActivity()).get(SoftwareStoreViewModel.class);
        mainUiStateViewModel = new ViewModelProvider(requireActivity()).get(MainUiStateViewModel.class);
        homeSoftwareStoreViewModel.getSoftwareList().observe(getViewLifecycleOwner(), roms -> {
            if (roms == null || roms.isEmpty()) {
                loadFromServer();
            } else {
                binding.linearload.setVisibility(View.GONE);
                data.clear();
                data.addAll(roms);
                mAdapter.notifyDataSetChanged();
            }
        });
    }

    private void loadFromServer() {
        if (mainUiStateViewModel != null) {
            mainUiStateViewModel.setSearchReady(false);
        }
        if (softwareStoreCallToHomeListener != null) {
            softwareStoreCallToHomeListener.updateSearchStatus(false);
        }

        net = new RequestNetwork(requireActivity());
        _net_request_listener = new RequestNetwork.RequestListener() {
            @Override
            public void onResponse(String tag, String response, HashMap<String, Object> responseHeaders) {
                if (!response.isEmpty())
                    contentJSON = response;
                loadData();
                binding.linearload.setVisibility(View.GONE);
            }

            @Override
            public void onErrorResponse(String tag, String message) {
                binding.linearload.setVisibility(View.GONE);
                binding.linearnothinghere.setVisibility(View.VISIBLE);
            }
        };

        binding.buttontryagain.setOnClickListener(v -> {
            binding.linearload.setVisibility(View.VISIBLE);
            net.startRequestNetwork(RequestNetworkController.GET, AppConfig.vectrasRaw + "software-store.json","",_net_request_listener);
        });

        net.startRequestNetwork(RequestNetworkController.GET, AppConfig.vectrasRaw + "software-store.json","",_net_request_listener);
    }

    private void loadData() {
        List<DataRoms> dataSoftware = new ArrayList<>();

        try {
            Gson gson = new Gson();
            Type listType = new TypeToken<List<DataRoms>>() {}.getType();
            dataSoftware = gson.fromJson(contentJSON, listType);
        } catch (Exception e) {
            binding.linearload.setVisibility(View.GONE);
            binding.linearnothinghere.setVisibility(View.VISIBLE);
        }

        dataSoftware = deduplicateByVecid(dataSoftware);

        homeSoftwareStoreViewModel.setSoftwareList(dataSoftware);
        data.clear();
        data.addAll(dataSoftware);
        mAdapter.notifyDataSetChanged();
        SharedData.dataSoftwareStore.clear();
        SharedData.dataSoftwareStore.addAll(dataSoftware);
        if (mainUiStateViewModel != null) {
            mainUiStateViewModel.setSearchReady(true);
        }
        if (softwareStoreCallToHomeListener != null) {
            softwareStoreCallToHomeListener.updateSearchStatus(true);
        }
    }

    private List<DataRoms> deduplicateByVecid(List<DataRoms> source) {
        Map<String, DataRoms> uniqueItems = new LinkedHashMap<>();

        for (int i = 0; i < source.size(); i++) {
            DataRoms software = source.get(i);
            if (software == null) continue;

            String vecid = software.vecid != null ? software.vecid.trim() : "";
            String key = vecid.isEmpty() ? "index:" + i : "vecid:" + vecid;
            uniqueItems.putIfAbsent(key, software);
        }

        return new ArrayList<>(uniqueItems.values());
    }
}