package com.vectras.vm.main.monitor;

import static android.content.Context.ACTIVITY_SERVICE;
import static android.os.Build.VERSION.SDK_INT;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.transition.MaterialFadeThrough;
import com.vectras.qemu.Config;
import com.vectras.qemu.MainSettingsManager;
import com.vectras.vm.R;
import com.vectras.vm.VMManager;
import com.vectras.vm.databinding.FragmentHomeSystemMonitorBinding;
import com.vectras.vm.utils.CommandUtils;
import com.vectras.vm.utils.DialogUtils;
import com.vectras.vterm.Terminal;
import com.vectras.vm.rafaelia.RafaeliaLogActivity;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class SystemMonitorFragment extends Fragment {
    final String TAG = "SystemMonitorFragment";
    FragmentHomeSystemMonitorBinding binding;
    ExecutorService executor = Executors.newSingleThreadExecutor();
    ScheduledExecutorService executorUpdate;
    boolean isStopUpdateMonitor = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setEnterTransition(new MaterialFadeThrough());
        setReturnTransition(new MaterialFadeThrough());
        setExitTransition(new MaterialFadeThrough());
        setReenterTransition(new MaterialFadeThrough());
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentHomeSystemMonitorBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        startMonitor();
        getQemuInfo();
        initialize();
    }

    @Override
    public void onResume() {
        super.onResume();
        if(isStopUpdateMonitor) {
            startMonitor();
            getQemuInfo();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        stopMonitor();
    }

    @Override
    public void onDestroyView() {
        stopMonitor();
        stopDelayedRefreshExecutor();
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onDestroy() {
        if (!executor.isShutdown()) {
            executor.shutdownNow();
        }
        super.onDestroy();
    }

    private void initialize() {
        binding.btStopqemu.setOnClickListener(v -> VMManager.requestKillAllQemuProcess(requireActivity(), () -> {
            startDelayedRefreshExecutor();
        }));

        binding.btRafaeliaLogs.setOnClickListener(v -> {
            Intent intent = new Intent(requireActivity(), RafaeliaLogActivity.class);
            startActivity(intent);
        });

        binding.btStopvmvnc.setOnClickListener(v -> {
            if (Config.currentVNCServervmID.isEmpty()) {
                binding.btStopvmvnc.setVisibility(View.GONE);
            } else {
                DialogUtils.threeDialog(
                        requireActivity(),
                        getString(R.string.shutdown),
                        getString(R.string.shutdown_or_reset_content),
                        getString(R.string.shutdown),
                        getString(R.string.reset),
                        getString(R.string.close),
                        true,
                        R.drawable.power_settings_new_24px,
                        true,
                        () -> {
                            Config.vmID = Config.currentVNCServervmID;
                            VMManager.shutdownCurrentVM();
                            Config.currentVNCServervmID = "";
                            binding.btStopvmvnc.setVisibility(View.GONE);
                            getQemuInfo();
                        },
                        () -> {
                            Config.vmID = Config.currentVNCServervmID;
                            VMManager.resetCurrentVM();
                        },
                        null,
                        null);
            }
        });
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable monitorTask = new Runnable() {
        @Override
        public void run() {
            if (isStopUpdateMonitor || !isAdded()) return;
            updateSystemMonitor();
            handler.postDelayed(this, 1000);
        }
    };

    private void startMonitor() {
        isStopUpdateMonitor = false;
        handler.post(monitorTask);
    }

    private void stopMonitor() {
        isStopUpdateMonitor = true;
        handler.removeCallbacks(monitorTask);
    }

    private void startDelayedRefreshExecutor() {
        stopDelayedRefreshExecutor();
        executorUpdate = Executors.newSingleThreadScheduledExecutor();
        executorUpdate.schedule(() -> {
            if (!isViewBindingAvailable()) {
                return;
            }
            requireActivity().runOnUiThread(() -> {
                if (isViewBindingAvailable()) {
                    getQemuInfo();
                }
            });
        }, 500, TimeUnit.MILLISECONDS);
    }

    private void stopDelayedRefreshExecutor() {
        if (executorUpdate != null && !executorUpdate.isShutdown()) {
            executorUpdate.shutdownNow();
        }
    }

    private boolean isViewBindingAvailable() {
        return isAdded() && binding != null;
    }

    @SuppressLint("SetTextI18n")
    private void updateSystemMonitor() {
        if (!isViewBindingAvailable()) return;

        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ActivityManager activityManager = (ActivityManager) requireActivity().getSystemService(ACTIVITY_SERVICE);
        activityManager.getMemoryInfo(mi);

        double totalMemory = mi.totalMem * Math.pow(10, -9);
        double freeMemory = mi.availMem * Math.pow(10, -9);
        double usedMemory = totalMemory - freeMemory;
        double percentageOfRam = (100 / totalMemory) * usedMemory;

        binding.tvTotalram.setText(getString(R.string.total_memory) + " " + String.format(Locale.US, "%.1f", totalMemory) + " GB");
        binding.tvUsedram.setText(getString(R.string.used_memory)  + " " + String.format(Locale.US, "%.1f", usedMemory) + " GB");
        binding.tvFreeram.setText(getString(R.string.free_memory)  + " " + String.format(Locale.US, "%.1f", freeMemory) + " GB");
        binding.tvPercentageofram.setText((int) percentageOfRam + "%");
        if (SDK_INT >= Build.VERSION_CODES.N) {
            binding.cpiMemory.setProgress((int) percentageOfRam, true);
        } else {
            binding.cpiMemory.setProgress((int) percentageOfRam);
        }


        StatFs externalStatFs = new StatFs( Environment.getExternalStorageDirectory().getAbsolutePath() );

        double totalStorage = (externalStatFs.getBlockCountLong() * externalStatFs.getBlockSizeLong()) * Math.pow(10, -9);
        double freeStorage = (externalStatFs.getAvailableBlocksLong() * externalStatFs.getBlockSizeLong()) * Math.pow(10, -9);
        double usedStorage = totalStorage - freeStorage;
        double percentageOfStorage = (100 / totalStorage) * usedStorage;

        binding.tvTotalstorage.setText(getString(R.string.total_memory) + " " + String.format(Locale.US, "%.1f", totalStorage) + " GB");
        binding.tvUsedstorage.setText(getString(R.string.used_memory)  + " " + String.format(Locale.US, "%.1f", usedStorage) + " GB");
        binding.tvFreestorage.setText(getString(R.string.free_memory)  + " " + String.format(Locale.US, "%.1f", freeStorage) + " GB");
        binding.tvPercentageofstorage.setText((int) percentageOfStorage + "%");
        if (SDK_INT >= Build.VERSION_CODES.N) {
            binding.cpiStorage.setProgress((int) percentageOfStorage, true);
        } else {
            binding.cpiStorage.setProgress((int) percentageOfStorage);
        }
    }

    @SuppressLint("SetTextI18n")
    private void getQemuInfo() {
        if (!isViewBindingAvailable()) return;

        String currentArch = MainSettingsManager.getArch(requireActivity());

        binding.tvQemuarch.setText(getString(R.string.arch) + " " + currentArch + ".");

        executor.execute(() -> {
            String qemuVersionName = CommandUtils.getQemuVersionName();
            if (!isViewBindingAvailable()) return;
            String result = Terminal.executeShellCommandWithResult("ps -e command && echo \"psendhere\" && cat /proc/cpuinfo", requireActivity());
            requireActivity().runOnUiThread(() -> {
                int markerIndex = result.indexOf("\npsendhere");
                if (result.isEmpty()) {
                    binding.tvProcesses.setText(getString(R.string.nothing_here));
                } else if (markerIndex >= 0) {
                    binding.tvProcesses.setText(result.substring(0, markerIndex));
                } else {
                    binding.tvProcesses.setText(result);
                }
                binding.tvQemuversion.setText(getString(R.string.version) + " " + (qemuVersionName.isEmpty() ? getString(R.string.unknow) : qemuVersionName) + ".");

                if (!result.isEmpty()) {
                    switch (currentArch) {
                        case "X86_64" ->
                                binding.tvQemustatus.setText(getString(R.string.status_qemu) + " " + (result.contains("qemu-system-x86_64 -qmp") ? getString(R.string.running) : getString(R.string.stopped)) + ".");
                        case "I386" ->
                                binding.tvQemustatus.setText(getString(R.string.status_qemu) + " " + (result.contains("qemu-system-i386 -qmp") ? getString(R.string.running) : getString(R.string.stopped)) + ".");
                        case "ARM64" ->
                                binding.tvQemustatus.setText(getString(R.string.status_qemu) + " " + (result.contains("qemu-system-aarch64 -qmp") ? getString(R.string.running) : getString(R.string.stopped)) + ".");
                        case "PPC" ->
                                binding.tvQemustatus.setText(getString(R.string.status_qemu) + " " + (result.contains("qemu-system-ppc -qmp") ? getString(R.string.running) : getString(R.string.stopped)) + ".");
                        default -> binding.tvQemustatus.setText(getString(R.string.status_qemu) + " " + getString(R.string.stopped) + ".");
                    }

                    if (result.contains("qemu-system") && result.contains("-qmp")) {
                        binding.btStopqemu.setVisibility(View.VISIBLE);
                    } else {
                        binding.btStopqemu.setVisibility(View.GONE);
                    }
                } else {
                    binding.tvQemustatus.setText(getString(R.string.status_qemu) + " " + getString(R.string.stopped) + ".");
                    binding.btStopqemu.setVisibility(View.GONE);
                    Log.i(TAG, "Errors: " + result);
                }

                getVNCServerStatus(result);
                get3dfxStatus(qemuVersionName, result);
            });
        });
    }

    @SuppressLint("SetTextI18n")
    private void getVNCServerStatus(String resultCommand) {
        if (!isViewBindingAvailable()) return;
        binding.tvVncport.setText(getString(R.string.port_qemu) + " " + (Integer.parseInt(MainSettingsManager.getVncExternalDisplay(requireActivity())) + 5900) + ".");

        if (resultCommand.contains(Config.defaultVNCHost + ":" + Config.defaultVNCPort)) {
            binding.tvVncstatus.setText(getString(R.string.status_qemu) + " " + getString(R.string.running) + ".");
            binding.btStopvmvnc.setVisibility(View.VISIBLE);
        } else {
            binding.tvVncstatus.setText(getString(R.string.status_qemu) + " " + getString(R.string.stopped) + ".");
            binding.btStopvmvnc.setVisibility(View.GONE);
        }
    }
    private void get3dfxStatus(String qemuVersion, String resultCommand) {
        if(qemuVersion.contains("3dfx")) {
            if (!isViewBindingAvailable()) return;
            binding.tv3dfxContent.setText(
                    requireActivity().getString(resultCommand.contains("crc32") || resultCommand.contains("sse4_2") ?
                            R.string.cpu_support_3dfx_content : R.string.cpu_not_support_3dfx_content));
        } else {
            if (!isViewBindingAvailable()) return;
            binding.tv3dfxContent.setText(getText(R.string.threedfx_is_not_available));
        }
    }

}
