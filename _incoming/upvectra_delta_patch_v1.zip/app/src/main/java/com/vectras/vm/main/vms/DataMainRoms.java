package com.vectras.vm.main.vms;
public class DataMainRoms {
    public String itemIcon;
    public String itemName;
    public String itemArch;
    public String itemCpu;
    public String itemPath;
    public String itemDrv1;
    public String itemExtra;
    public String imgCdrom;
    public String vmID;
    public int qmpPort;
}
