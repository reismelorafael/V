package com.vectras.vm;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.vectras.vm.databinding.ActivityExportRomBinding;
import com.vectras.vm.utils.DialogUtils;
import com.vectras.vm.utils.FileUtils;
import com.vectras.vm.utils.PackageUtils;
import com.vectras.vm.utils.UIUtils;
import com.vectras.vm.utils.ZipUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

public class ExportRomActivity extends AppCompatActivity {

    ActivityExportRomBinding binding;
    public static int pendingPosition = 0;
    public static HashMap<String, Object> mapForGetData = new HashMap<>();
    public static ArrayList<HashMap<String, Object>> listmapForGetData = new ArrayList<>();
    private SharedPreferences data;
    public String getRomPath = "";
    public String iconfile = "";
    public String diskfile = "";
    public String cdromfile = "";
    private boolean isExporting = false;
    private String[] pendingExportFilePaths = new String[0];
    private String pendingExportDisplayName = "vm-export.cvbi";

    private final ActivityResultLauncher<String> exportCvbiLauncher =
            registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"), uri -> {
                if (uri == null) {
                    return;
                }
                runExport(pendingExportFilePaths, uri, pendingExportDisplayName);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UIUtils.edgeToEdge(this);
        binding = ActivityExportRomBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        UIUtils.setOnApplyWindowInsetsListener(findViewById(R.id.main));
        binding.appbar.post(() -> binding.appbar.setExpanded(false, false));
        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        binding.btnDone.setOnClickListener(v -> {
            binding.edAuthor.setEnabled(false);
            binding.edContent.setEnabled(false);
            binding.edAuthor.setEnabled(true);
            binding.edContent.setEnabled(true);
            startCreate();
        });

        data = getSharedPreferences("data", Activity.MODE_PRIVATE);

        binding.edAuthor.setText(data.getString("author", ""));
        binding.edContent.setText(data.getString("desc", ""));

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                onBack();
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        data.edit().putString("author", Objects.requireNonNull(binding.edAuthor.getText()).toString()).apply();
        data.edit().putString("desc", Objects.requireNonNull(binding.edContent.getText()).toString()).apply();
    }

    private void onBack() {
        if (!isExporting) finish();
    }

    @SuppressLint("SetTextI18n")
    private void startCreate() {
        File vDir = new File(AppConfig.cvbiFolder);
        if (!vDir.exists()) {
            if (!vDir.mkdirs()) {
                DialogUtils.oneDialog(this,
                        getString(R.string.oops),
                        getString(R.string.could_not_create_dir_to_save_cvbi_content),
                        getString(R.string.ok),
                        true,
                        R.drawable.error_96px,
                        true,
                        null,
                        this::finish
                );
            }
        }

        listmapForGetData.clear();
        mapForGetData.clear();

        listmapForGetData = new Gson().fromJson(FileUtils.readAFile(AppConfig.romsdatajson), new TypeToken<ArrayList<HashMap<String, Object>>>() {
        }.getType());

        getRomPath = AppConfig.vmFolder + Objects.requireNonNull(listmapForGetData.get(pendingPosition).get("vmID")) + "/";

        if (listmapForGetData.get(pendingPosition).containsKey("imgName")) {
            mapForGetData.put("title", Objects.requireNonNull(listmapForGetData.get(pendingPosition).get("imgName")).toString());
        } else {
            mapForGetData.put("title", "");
        }
        if (listmapForGetData.get(pendingPosition).containsKey("imgIcon")) {
            iconfile = Objects.requireNonNull(listmapForGetData.get(pendingPosition).get("imgIcon")).toString();
            try {
                mapForGetData.put("icon", Uri.parse(Objects.requireNonNull(listmapForGetData.get(pendingPosition).get("imgIcon")).toString()).getLastPathSegment());
            } catch (Exception _e) {
                mapForGetData.put("icon", Objects.requireNonNull(listmapForGetData.get(pendingPosition).get("imgIcon")).toString());
            }
        } else {
            mapForGetData.put("icon", "");
        }
        if (listmapForGetData.get(pendingPosition).containsKey("imgPath")) {
            if (Objects.requireNonNull(listmapForGetData.get(pendingPosition).get("imgPath")).toString().isEmpty()) {
                diskfile = VMManager.quickScanDiskFileInFolder(getRomPath);
            } else {
                diskfile = Objects.requireNonNull(listmapForGetData.get(pendingPosition).get("imgPath")).toString();
            }
            mapForGetData.put("drive", diskfile.isEmpty() ? "" : diskfile.replace(getRomPath, ""));
        } else {
            diskfile = VMManager.quickScanDiskFileInFolder(getRomPath);
            mapForGetData.put("drive", diskfile.isEmpty() ? "" : diskfile.replace(getRomPath, ""));
        }
        if (listmapForGetData.get(pendingPosition).containsKey("imgCdrom")) {
            if (Objects.requireNonNull(listmapForGetData.get(pendingPosition).get("imgCdrom")).toString().isEmpty()) {
                cdromfile = VMManager.quickScanISOFileInFolder(getRomPath);
            } else {
                cdromfile = Objects.requireNonNull(listmapForGetData.get(pendingPosition).get("imgCdrom")).toString();
            }
            mapForGetData.put("cdrom", cdromfile.isEmpty() ? "" : cdromfile.replace(getRomPath, ""));
        } else {
            cdromfile = VMManager.quickScanISOFileInFolder(getRomPath);
            mapForGetData.put("cdrom", cdromfile.isEmpty() ? "" : cdromfile.replace(getRomPath, ""));
        }
        if (listmapForGetData.get(pendingPosition).containsKey("imgExtra")) {
            mapForGetData.put("qemu", Objects.requireNonNull(listmapForGetData.get(pendingPosition).get("imgExtra")).toString().replace(getRomPath, "OhnoIjustrealizeditsmidnightandIstillhavetodothis"));
        } else {
            mapForGetData.put("qemu", "");
        }
        if (listmapForGetData.get(pendingPosition).containsKey("imgArch")) {
            mapForGetData.put("arch", Objects.requireNonNull(listmapForGetData.get(pendingPosition).get("imgArch")).toString());
        } else {
            mapForGetData.put("arch", "");
        }
        if (Objects.requireNonNull(binding.edAuthor.getText()).toString().isEmpty()) {
            mapForGetData.put("author", "Unknow");
        } else {
            mapForGetData.put("author", binding.edAuthor.getText().toString());
        }
        if (Objects.requireNonNull(binding.edContent.getText()).toString().isEmpty()) {
            mapForGetData.put("desc", "Empty.");
        } else {
            mapForGetData.put("desc", binding.edContent.getText().toString());
        }

        mapForGetData.put("versioncode", PackageUtils.getThisVersionCode(getApplicationContext()));

        FileUtils.writeToFile(new File(String.valueOf(getExternalFilesDir("data"))).getPath(), "rom-data.json", new Gson().toJson(mapForGetData));

        String[] filePaths = new String[0];

        ArrayList<String> _filelist = new ArrayList<>();
        FileUtils.getAListOfAllFilesAndFoldersInADirectory(AppConfig.vmFolder + Objects.requireNonNull(listmapForGetData.get(pendingPosition).get("vmID")), _filelist);
        if (!_filelist.isEmpty()) {
            for (int _repeat = 0; _repeat < _filelist.size(); _repeat++) {
                if (!_filelist.get(_repeat).endsWith("vmID.txt") &&
                        !_filelist.get(_repeat).endsWith("vmID.old.txt") &&
                        !_filelist.get(_repeat).endsWith("cqcm.json")) {
                    filePaths = java.util.Arrays.copyOf(filePaths, filePaths.length + 1);
                    filePaths[filePaths.length - 1] = !_filelist.get(_repeat).endsWith("rom-data.json") ? _filelist.get(_repeat) : getExternalFilesDir("data") + "/rom-data.json";
                }
            }
        }

        String outputFileName = Objects.requireNonNull(mapForGetData.get("title")).toString().trim();
        if (outputFileName.isEmpty()) {
            outputFileName = "vm-export";
        }
        if (!outputFileName.endsWith(".cvbi")) {
            outputFileName += ".cvbi";
        }

        pendingExportFilePaths = filePaths;
        pendingExportDisplayName = outputFileName;

        exportCvbiLauncher.launch(outputFileName);
    }

    @SuppressLint("SetTextI18n")
    private void runExport(String[] filePaths, Uri outputUri, String outputDisplayName) {
        View progressView = LayoutInflater.from(this).inflate(R.layout.dialog_progress_style, null);
        TextView progressText = progressView.findViewById(R.id.progress_text);
        progressText.setText(getString(R.string.exporting) + "\n" + getString(R.string.please_stay_here));
        ProgressBar progressBar = progressView.findViewById(R.id.progress_bar);
        AlertDialog progressDialog = new MaterialAlertDialogBuilder(this, R.style.CenteredDialogTheme)
                .setView(progressView)
                .setCancelable(false)
                .create();

        progressDialog.show();

        new Thread(() -> {
            isExporting = true;

            boolean result = ZipUtils.compressToUri(
                    this,
                    filePaths,
                    outputUri,
                    progressText,
                    progressBar
            );

            Uri savedUri = outputUri;
            if (!result && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                Uri fallback = ZipUtils.createMediaStoreDownloadUri(this, outputDisplayName);
                if (fallback != null) {
                    result = ZipUtils.compressToUri(
                            this,
                            filePaths,
                            fallback,
                            progressText,
                            progressBar
                    );
                    if (result) {
                        savedUri = fallback;
                    }
                }
            }

            final boolean finalResult = result;
            final Uri finalSavedUri = savedUri;
            runOnUiThread(() -> {
                isExporting = false;
                progressDialog.dismiss();

                String title;
                String content;
                if (finalResult) {
                    title = getString(R.string.done);
                    content = getString(R.string.saved_in) + ": " + finalSavedUri + ".";
                } else {
                    title = getString(R.string.oops);
                    content = getString(R.string.something_went_wrong) + ":\n\n" + ZipUtils.lastErrorContent;
                }

                DialogUtils.twoDialog(this,
                        title,
                        content,
                        getString(R.string.ok),
                        getString(finalResult ? R.string.close : R.string.exit),
                        true,
                        finalResult ? R.drawable.check_24px : R.drawable.error_96px,
                        true,
                        null,
                        () -> {
                            if (!finalResult) {
                                finish();
                            }
                        },
                        null);
            });
        }).start();
    }
}
