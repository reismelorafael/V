# Vectras VM — Runtime & Engine Systems

## Resumo
Mapa técnico para estudar o runtime de virtualização, integração Android↔QEMU e componentes de engine (`engine/rmr/`) com foco em execução determinística e rastreável.

## Escopo
- Coberto:
  - Arquitetura de runtime, integração com engine e trilha de documentação técnica.
  - Pontos de entrada para investigação de boot, supervisão e ciclo de execução.
- Não coberto:
  - Implementações fora do repositório ou sem vínculo documental com caminhos reais de código.

## Trilhas primárias
- `docs/ARCHITECTURE.md`
- `docs/INTEGRACAO_RM_QEMU_ANDROIDX.md`
- `docs/VM_SUPERVISION_AUDIT_EVIDENCE.md`
- `docs/BLUEPRINT_FLUXOS_VM.md`
- `docs/REPO_XRAY.md`

## Metadados
- Versão: 1.0
- Última atualização: 2026-02
- Responsável: manutenção documental
- Licença: GPL-2.0
