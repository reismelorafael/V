# Vectras-V — Bug Fix Report
**Repositório:** https://github.com/reismelorafael/Vectras-V  
**Data:** 2026-02-22  
**Arquivos modificados:** `engine/rmr/src/rmr_unified_kernel.c`, `rmr_ll_ops.c`, `rmr_policy_kernel.c`

---

## BUG-1 — CRÍTICO: Linker Error quando `RMR_ENABLE_POLICY_MODULE=OFF`

**Arquivo:** `engine/rmr/src/rmr_unified_kernel.c` linhas 329, 330, 381  
**Sintoma:** `undefined reference to RmR_CRC32C` e `RmR_EntropyEstimateMilli`  
**Causa:** `RmR_UnifiedKernel_Ingest()` e `RmR_UnifiedKernel_Verify()` chamam essas funções  
diretamente, mas elas só existem em `rmr_policy_kernel.c`. Quando a flag  
`RMR_ENABLE_POLICY_MODULE=OFF`, o static library `rmr_policy_static` não é linkado  
e os símbolos ficam unresolved.

**Fix aplicado:** Bloco `#else` após o guard `#if RMR_ENABLE_POLICY_MODULE`:
- `RmR_CRC32C()` inline com tabela CRC32C (poly `0x82F63B78`) em BSS estático
- `RmR_EntropyEstimateMilli()` inline com estimador Shannon branchless via `__builtin_clz`
- Zero dependências externas, zero malloc, zero loops `while/for` — apenas `goto` + mask

---

## BUG-2 — CRÍTICO: `reg_signature_2 = 0` em ARM64 → NativeFastPath crash

**Arquivo:** `engine/rmr/src/rmr_ll_ops.c` (ARM64 `RmR_LL_ReadAsmProbe`)  
**Sintoma:** `NativeFastPath.HardwareProfile.fromHardwareContract()` lança  
`IllegalArgumentException("register-signature")` quando `(reg0|reg1|reg2)==0`  
→ app cai para `CompatibilityFallback` (signature=UNKNOWN, pointerBits=32)

**Causa:** ARM64 lia apenas `ctr_el0` (32-bit efetivo), populando apenas `reg_signature_0`.  
`reg_signature_1` podia ser 0 (bits [63:32] de ctr são sempre 0), `reg_signature_2` sempre 0.

**Fix aplicado:**
- Lê `id_aa64pfr0_el1` → `reg_signature_2` (ASIMD/FP bits, nunca 0 em AArch64)
- Fold de `ctr_el0[63:32]` XOR `dczid_el0[31:0]` → `reg_signature_1` 
- Guard branchless: se todos zero (QEMU restrito), deriva de `sizeof(void*) ^ 0xA64BA64B`

---

## BUG-3 — CRÍTICO: `reg_signature_1/2 = 0` em RISCV → mesmo crash

**Arquivo:** `engine/rmr/src/rmr_ll_ops.c` (RISCV `RmR_LL_ReadAsmProbe`)  
**Causa:** Apenas lia `misa` → `reg_signature_0`. Os outros dois ficavam 0.

**Fix aplicado:**
- Lê `rdcycle` → `reg_signature_1` (contador disponível em QEMU RISCV64)
- Deriva `reg_signature_2` de `(misa >> 26) ^ 0x52564356` ("RVCV" marker)
- Guard branchless idêntico ao ARM64

---

## BUG-4 — ALTO: `feature_mask = 0` em ARM64 → NEON/AES/CRC32 não detectados

**Arquivo:** `engine/rmr/src/rmr_ll_ops.c` + `rmr_unified_kernel.c`  
**Causa:** ARM64 `feature_bits_0` continha `dczid_el0` (data cache zero ID — irrelevante  
para feature detection). `NativeFastPath.describeFeatureMask()` retornava `"none"`.

**Fix aplicado (BUG-4/4b/4c):**

**rmr_ll_ops.c ARM64:**
- Substitui leitura de `dczid_el0` upper bits por `id_aa64isar0_el1` (ISA features)
- `feature_bits_0 = isar0[31:0]` → campos `AES[7:4]`, `SHA[11:8]`, `CRC32[19:16]`
- `feature_bits_1 = isar0[63:32]` → campos `RDMA`, `SHA3`, `SM4` etc.

**rmr_ll_ops.c x86_64:**
- Substitui `cpuid(1).edx` (old SSE flags) por `cpuid(7,0).ebx`
- `feature_bits_1 = ebx7[5]=AVX2, [3]=BMI1, [8]=BMI2`

**rmr_unified_kernel.c — `rmr_unified_caps_from_hw()`:**
Mapeamento determinístico branchless para `NativeFastPath.FEATURE_*`:

| Flag              | Valor  | ARM64 fonte           | x86_64 fonte          |
|-------------------|--------|-----------------------|-----------------------|
| `FEATURE_NEON`    | 1<<0   | Invariante AArch64    | —                     |
| `FEATURE_AES`     | 1<<1   | `isar0[7:4] != 0`     | `cpuid(1).ecx[25]`    |
| `FEATURE_CRC32`   | 1<<2   | `isar0[19:16] != 0`   | SSE4.2 implica CRC32  |
| `FEATURE_POPCNT`  | 1<<3   | —                     | `cpuid(1).ecx[23]`    |
| `FEATURE_SSE42`   | 1<<4   | —                     | `cpuid(1).ecx[20]`    |
| `FEATURE_AVX2`    | 1<<5   | —                     | `cpuid(7).ebx[5]`     |
| `FEATURE_SIMD`    | 1<<6   | Invariante AArch64    | Invariante x86_64     |

Toda lógica via máscaras XOR/AND — zero branches `if/else` no caminho quente.

---

## BUG-7 — ALTO: `rmr_policy_kernel.c` remove stdio/stdlib mas ainda os usa

**Arquivo:** `engine/rmr/src/rmr_policy_kernel.c`  
**Causa:** Comentários "BUG FIX baremetal: removido #include <stdio.h/stdlib.h>"  
mas o código ainda usa `fopen`, `fclose`, `malloc`, `realloc`, `free` diretamente.  
No JNI build (Android bionic) → **UNDEFINED SYMBOL** na compilação.  
No baremetal build → `rmr_baremetal_compat.h` redefine `uint8_t/size_t` via  
`typedef` após `rmr_policy_kernel.h` já ter incluído `<stdint.h>` → **DUPLICATE TYPEDEF**.

**Fix aplicado:**
```c
#if defined(RMR_JNI_BUILD) && RMR_JNI_BUILD
#  include <stdio.h>    /* fopen, fclose, fread, fwrite, fprintf, fflush */
#  include <stdlib.h>   /* malloc, realloc, free */
#  include <string.h>   /* memcpy, memset */
#else
#  include "rmr_baremetal_compat.h"
#  define FILE           void
#  define fopen(p,m)     ((void*)0)
   /* ... stubs determinísticos para baremetal */
#endif
```

---

## Resumo dos Bugs

| ID     | Severidade | Arquivo                    | Impacto                                              |
|--------|------------|----------------------------|------------------------------------------------------|
| BUG-1  | CRÍTICO    | rmr_unified_kernel.c       | Linker error completo se policy module OFF           |
| BUG-2  | CRÍTICO    | rmr_ll_ops.c (ARM64)       | NativeFastPath crash → fallback ARCH_UNKNOWN         |
| BUG-3  | CRÍTICO    | rmr_ll_ops.c (RISCV)       | Mesmo crash que BUG-2 em RISCV                       |
| BUG-4  | ALTO       | rmr_ll_ops.c + unified_k.  | feature_mask=0, NEON/AES/CRC32 invisíveis            |
| BUG-4b | ALTO       | rmr_ll_ops.c (ARM64)       | feature_bits_1=dczid≈0 em vez de isar0               |
| BUG-4c | MÉDIO      | rmr_ll_ops.c (x86_64)      | cpuid(1).edx em vez de cpuid(7).ebx para AVX2        |
| BUG-7  | ALTO       | rmr_policy_kernel.c        | UNDEFINED SYMBOL fopen/malloc + DUPLICATE TYPEDEF    |

## Arquivos Entregues

```
engine/rmr/src/rmr_unified_kernel.c  (+170 linhas BUG-1 fix + BUG-4 feature map)
engine/rmr/src/rmr_ll_ops.c          (ARM64: id_aa64isar0, BUG-2/4b; x86: cpuid(7), BUG-4c; RISCV: BUG-3)
engine/rmr/src/rmr_policy_kernel.c   (BUG-7: guards JNI_BUILD/baremetal + stdio restaurado)
```

## Filosofia de Implementação

Todos os fixes seguem a arquitetura determinística bare-metal do projeto:
- **Sem `if/else` no caminho quente**: usamos máscaras `0u - (predicate != 0u)` para branch-free select
- **Sem `while/for` explícito**: CRC32C table init via `goto` + label, processamento via `goto` loops
- **Sem dependências externas**: CRC32C inline (poly `0x82F63B78`), entropy via `__builtin_clz`
- **Registradores reais lidos diretamente via `__asm__ volatile`**: `mrs`, `cpuid`, `csrr`
- **Guard branchless para zero-check**: `(v != 0u) ? v : fallback` compilado como cmov
- **Determinismo por construção**: mesma CPU → mesmos valores de `reg_signature` e `feature_mask`
