# RafGitTools - Build Fixes para Android 15 (API 35)

## Problemas Corrigidos

### 1. `build.gradle` (raiz) — Versões Inexistentes

| Dependency | Versão Original (❌ não existe) | Versão Corrigida (✅) |
|---|---|---|
| AGP (Android Gradle Plugin) | `8.13.2` | `8.7.3` |
| Kotlin | `2.3.0` | `2.1.0` |
| Hilt Gradle Plugin | `2.58` | `2.51.1` |
| KSP | `2.3.4` | `2.1.0-1.0.29` |
| Compose Kotlin Plugin | `2.3.0` | `2.1.0` |

### 2. `app/build.gradle` — Versões Inexistentes

| Dependency | Versão Original (❌) | Versão Corrigida (✅) |
|---|---|---|
| `compileSdk` / `targetSdk` | `36` (não lançado) | `35` |
| `minSdk` | `24` | `26` |
| `core-ktx` | `1.17.0` | `1.13.1` |
| `lifecycle-*` | `2.10.0` | `2.8.7` |
| `activity-compose` | `1.12.2` | `1.9.3` |
| `compose-bom` | `2026.01.00` | `2024.12.01` |
| `navigation-compose` | `2.9.6` | `2.8.4` |
| `hilt-android` | `2.58` | `2.51.1` |
| `hilt-navigation-compose` | `1.3.0` | `1.2.0` |
| `room` | `2.8.4` | `2.6.1` |
| `retrofit` | `3.0.0` | `2.11.0` |
| `okhttp` | `5.3.2` | `4.12.0` |
| `gson` | `2.13.2` | `2.11.0` |
| `jgit` | `7.5.0.202512021534-r` | `6.10.0.202406032230-r` |
| `jsch (mwiede)` | `2.27.7` | `0.2.19` |
| `datastore` | `1.2.0` | `1.1.1` |
| `commonmark` | `0.27.1` | `0.22.0` |
| `work-runtime-ktx` | `2.11.0` | `2.9.1` |
| `core-splashscreen` | `1.2.0` | `1.0.1` |
| `kotlinx-coroutines-test` | `1.10.2` | `1.8.1` |
| `mockk` | `1.14.7` | `1.13.12` |
| `truth` | `1.4.5` | `1.4.2` |
| `junit (androidTest)` | `1.3.0` | `1.2.1` |
| `espresso-core` | `3.7.0` | `3.6.1` |

### 3. `gradle/wrapper/gradle-wrapper.properties`

| | Original (❌) | Corrigido (✅) |
|---|---|---|
| Gradle version | `8.13` | `8.9` |

### 4. `MainActivity.kt` — Import Não Utilizado

```kotlin
// REMOVIDO (import existe mas LanguageFAB nunca é chamado no arquivo)
import com.rafgittools.ui.components.LanguageFAB
```

## Como Compilar

```bash
# 1. Clone o repo
git clone https://github.com/rafaelmeloreisnovo/RafGitTools
cd RafGitTools

# 2. Aplique as correções (use os arquivos corrigidos neste PR)

# 3. Build debug (flavor dev)
./gradlew assembleDevDebug

# 4. Build release assinado com debug key
./gradlew assembleDevRelease

# 5. Instalar no dispositivo Android 15
adb install app/build/outputs/apk/dev/debug/app-dev-debug.apk
```

## Notas Técnicas

- **minSdk 26**: O projeto usa `Base64.getEncoder()` (API 26+) e Android Keystore features que funcionam melhor desde API 26.
- **JGit 6.10.x**: Versão estável mais recente disponível no Maven Central. JGit 7.x não existe publicamente.
- **mwiede/jsch 0.2.19**: Fork drop-in do jcraft/jsch, mantém pacotes `com.jcraft.jsch.*` idênticos.
- **Compose BOM 2024.12.01**: Última BOM estável para uso com compileSdk 35.
