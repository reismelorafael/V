# RafGitTools — Correções Aplicadas

## ✅ Arquivos integrados da pasta `fazer/` → `app/src/main/kotlin/`

| Arquivo | Destino | O que corrigiu |
|---|---|---|
| `AuthScreen.kt` | `ui/screens/auth/` | AuthScreen com 2 abas: PAT e OAuth Device Flow |
| `AuthViewModel.kt` | `ui/screens/auth/` | `startOAuthFlow()`, `cancelOAuth()`, estados OAuth |
| `CommitDetailScreen.kt` | `ui/screens/commits/` | UI completa: 3 tabs (Info, Files, Diff) — substituiu placeholder "coming soon" |
| `CommitDetailViewModel.kt` | `ui/screens/commits/` | ViewModel criado do zero (não existia) |
| `DiffViewerScreen.kt` | `ui/screens/diff/` | `buildSideBySidePairs()` — painéis side-by-side não ficam mais em branco |
| `HomeViewModel.kt` | `ui/screens/home/` | Scan de repos locais via JGitService + tabs REMOTE/LOCAL |
| `MultiAccountManager.kt` | `core/security/` | Múltiplas contas GitHub: add, switch, remove, token encriptado |
| `NotificationsViewModel.kt` | `ui/screens/notifications/` | `loadNotifications()`, `markAsRead()`, `markAllAsRead()`, toggle showAll |
| `OAuthDeviceFlowManager.kt` | `data/auth/` | OAuth Device Flow completo (RFC 8628) |
| `ReleaseDetailScreen.kt` | `ui/screens/releases/` | UI completa: badge pre-release/draft, assets, release notes, autor |
| `ReleaseDetailViewModel.kt` | `ui/screens/releases/` | `loadRelease()` real via GithubApiService |
| `ReleasesViewModel.kt` | `ui/screens/releases/` | Paginação real, `loadReleases()`, `loadNextPage()` |
| `SyntaxHighlighter.kt` | `ui/components/` | Syntax highlighter puro Kotlin/Compose (Kotlin, Java, Python, JS, XML, JSON, etc.) |
| `TerminalScreen.kt` | `ui/screens/terminal/` | UI de terminal: fundo escuro, output colorido, chips de atalho |
| `TerminalViewModel.kt` | `ui/screens/terminal/` | Terminal com ProcessBuilder, histórico, whitelist de comandos |
| `TokenRefreshManager.kt` | `data/auth/` | Detecção de token expirado/revogado via 401/403 |

## 🔧 Correções em arquivos existentes

### `app/build.gradle`
- **Adicionado** `GITHUB_CLIENT_ID` buildConfigField em ambos os flavors (`dev` e `production`)
- **Corrigido** Room version: `2.8.4` → `2.7.1` (versão estável conhecida)

### `build.gradle` (root)
- **Corrigido** KSP version: `2.3.4` → `2.3.0-1.0.25` (deve corresponder à versão Kotlin `2.3.0`)

### `data/auth/OAuthDeviceFlowManager.kt`
- **Corrigido** `CLIENT_ID` para usar `BuildConfig.GITHUB_CLIENT_ID` em vez de hardcoded string

## ⚠️ Configuração necessária após merge

```bash
# 1. Definir GitHub OAuth Client ID real:
# Em app/build.gradle, ambos os flavors — substituir:
buildConfigField "String", "GITHUB_CLIENT_ID", '"Iv1.your_github_client_id"'
# Por:
buildConfigField "String", "GITHUB_CLIENT_ID", '"Iv1.SEU_CLIENT_ID_REAL"'
# Obter em: https://github.com/settings/developers → OAuth Apps

# 2. Verificar compatibilidade KSP+Kotlin:
# Se build falhar por versão KSP incompatível, ajustar em build.gradle (root):
# id 'com.google.devtools.ksp' version '2.3.0-1.0.25'
# Consultar: https://github.com/google/ksp/releases
```

## 📊 Status após correções

| Categoria | Status |
|---|---|
| Arquivos de compilação | ✅ Limpos |
| Shells UI (telas com placeholder) | ✅ Preenchidas |
| Features OAuth Device Flow | ✅ Implementadas |
| Terminal | ✅ Implementado |
| Syntax Highlighting | ✅ Implementado |
| Multi-conta | ✅ Implementado |
| Token Refresh | ✅ Implementado |
| Arquivo fantasma (`data/network/r`) | ✅ Não presente no clone atual |

## 🔴 Gaps que ainda requerem sprints separadas

- **P33-05**: Interactive staging (hunks) — UI complexa
- **P33-11**: Git config management — nova tela
- **P33-26/27/28**: SSH key UI — SshKeyManager.kt existe mas UI de gestão incompleta
- **P33-29**: Biometric wiring — BiometricAuthManager.kt existe mas não está conectado em Settings
