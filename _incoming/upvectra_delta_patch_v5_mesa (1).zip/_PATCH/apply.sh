#!/bin/sh
set -eu
ROOT="${1:-.}"
copy_one() { src="$1"; dst="$2"; mkdir -p "$(dirname "$dst")"; cp -f "$src" "$dst"; }
BASE="$(cd "$(dirname "$0")/.." && pwd)"
echo "Applying v5 mesa patch to: $ROOT"
copy_one "$BASE/app/src/main/java/com/vectras/vm/core/ProcessRuntimeOps.java" "$ROOT/app/src/main/java/com/vectras/vm/core/ProcessRuntimeOps.java"
copy_one "$BASE/app/src/main/java/com/vectras/vm/core/ProcessSupervisor.java" "$ROOT/app/src/main/java/com/vectras/vm/core/ProcessSupervisor.java"
copy_one "$BASE/app/src/main/res/layout/activity_about.xml" "$ROOT/app/src/main/res/layout/activity_about.xml"
copy_one "$BASE/app/src/main/res/layout/activity_external_vnc_settings.xml" "$ROOT/app/src/main/res/layout/activity_external_vnc_settings.xml"
copy_one "$BASE/app/src/main/res/layout/activity_import_export_settings.xml" "$ROOT/app/src/main/res/layout/activity_import_export_settings.xml"
copy_one "$BASE/app/src/main/res/layout/activity_theme.xml" "$ROOT/app/src/main/res/layout/activity_theme.xml"
copy_one "$BASE/app/src/main/res/layout/activity_updater.xml" "$ROOT/app/src/main/res/layout/activity_updater.xml"
copy_one "$BASE/app/src/main/res/layout/activity_vm_creator.xml" "$ROOT/app/src/main/res/layout/activity_vm_creator.xml"
copy_one "$BASE/app/src/main/res/layout/activity_vnc_settings.xml" "$ROOT/app/src/main/res/layout/activity_vnc_settings.xml"
copy_one "$BASE/app/src/main/res/layout/activity_x11_display_settings.xml" "$ROOT/app/src/main/res/layout/activity_x11_display_settings.xml"
copy_one "$BASE/app/src/main/res/layout/importexport.xml" "$ROOT/app/src/main/res/layout/importexport.xml"
copy_one "$BASE/app/src/main/res/layout/main_vnc.xml" "$ROOT/app/src/main/res/layout/main_vnc.xml"
echo "OK: applied v5 mesa patch"
