# v5 mesa patch (delta only)

Fixes:
- Build breaker: app/src/main/res/layout/importexport.xml (XML declaration first; remove stray lines)
- Close reliability: ProcessRuntimeOps.forceKillTree + ProcessSupervisor fallback kill-tree
- Mesa hygiene: remove stray attribute text nodes after CollapsingToolbarLayout in multiple activities
- Add missing layout_width/layout_height to MaterialToolbar in those activities
- Fix main_vnc.xml: move stray layout_width/layout_height into TableRow attributes

Files touched: 12
